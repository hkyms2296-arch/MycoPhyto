import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const MycoPhytoApp());

class MycoPhytoApp extends StatelessWidget {
  const MycoPhytoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MycoPhyto',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF168447),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF6FAF6),
      ),
      home: const HomePage(),
    );
  }
}

enum CatalogType { plant, fungus }

class CatalogItem {
  const CatalogItem({
    required this.commonName,
    required this.scientificName,
    required this.type,
    required this.summary,
  });

  final String commonName;
  final String scientificName;
  final CatalogType type;
  final String summary;
}

const items = <CatalogItem>[
  CatalogItem(
    commonName: 'Tomato',
    scientificName: 'Solanum lycopersicum',
    type: CatalogType.plant,
    summary: 'Crop reference. Compare symptoms across leaves, stems and fruit.',
  ),
  CatalogItem(
    commonName: 'Common wheat',
    scientificName: 'Triticum aestivum',
    type: CatalogType.plant,
    summary: 'Cereal crop reference. Record field pattern and growth stage.',
  ),
  CatalogItem(
    commonName: 'Gray mold fungus',
    scientificName: 'Botrytis cinerea',
    type: CatalogType.fungus,
    summary: 'Plant pathogen associated with gray mold; confirm with a reliable diagnostic method.',
  ),
  CatalogItem(
    commonName: 'Button mushroom',
    scientificName: 'Agaricus bisporus',
    type: CatalogType.fungus,
    summary: 'Cultivated mushroom reference. Never eat wild mushrooms based on an app result.',
  ),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _search = TextEditingController();
  final _picker = ImagePicker();
  CatalogType? _type;
  XFile? _photo;

  List<CatalogItem> get _results {
    final query = _search.text.trim().toLowerCase();
    return items.where((item) {
      final matchesType = _type == null || item.type == _type;
      final matchesQuery = query.isEmpty ||
          item.commonName.toLowerCase().contains(query) ||
          item.scientificName.toLowerCase().contains(query);
      return matchesType && matchesQuery;
    }).toList();
  }

  Future<void> _selectPhoto(ImageSource source) async {
    try {
      final photo = await _picker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1800,
      );
      if (!mounted || photo == null) return;
      setState(() => _photo = photo);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Photo selected. Automated identification is not connected yet.'),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open the image source. Check permissions.')),
      );
    }
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final results = _results;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF116B3A),
        foregroundColor: Colors.white,
        title: const Text('MycoPhyto', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        leading: const Padding(
          padding: EdgeInsets.all(12),
          child: Icon(Icons.eco, color: Colors.white),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF116B3A), Color(0xFF38A65B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.biotech, color: Colors.white, size: 36),
                SizedBox(height: 10),
                Text(
                  'Plant & Fungi Explorer',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 6),
                Text(
                  'Explore scientific references and prepare photos for future identification.',
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search common or scientific name',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 12),
          SegmentedButton<CatalogType?>(
            segments: const [
              ButtonSegment<CatalogType?>(value: null, label: Text('All')),
              ButtonSegment<CatalogType?>(value: CatalogType.plant, label: Text('Plants')),
              ButtonSegment<CatalogType?>(value: CatalogType.fungus, label: Text('Fungi')),
            ],
            selected: {_type},
            onSelectionChanged: (selection) => setState(() => _type = selection.first),
          ),
          const SizedBox(height: 14),
          Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Photo tools', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Select a plant or fungus photo. This starter does not yet predict species or diagnose disease.'),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: () => _selectPhoto(ImageSource.camera),
                        icon: const Icon(Icons.camera_alt),
                        label: const Text('Camera'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => _selectPhoto(ImageSource.gallery),
                        icon: const Icon(Icons.photo_library),
                        label: const Text('Gallery'),
                      ),
                    ],
                  ),
                  if (_photo != null) ...[
                    const SizedBox(height: 8),
                    Text('Selected: ${_photo!.name}', style: const TextStyle(fontSize: 12)),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text('Reference catalog · ${results.length}', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 4),
          ...results.map((item) => Card(
                color: Colors.white,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFE2F3E6),
                    child: Icon(
                      item.type == CatalogType.plant ? Icons.eco : Icons.spa,
                      color: const Color(0xFF116B3A),
                    ),
                  ),
                  title: Text(item.commonName, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('${item.scientificName}\n${item.summary}'),
                  ),
                  isThreeLine: true,
                  trailing: Icon(item.type == CatalogType.plant ? Icons.grass : Icons.biotech),
                ),
              )),
          const SizedBox(height: 16),
          const Text(
            'Scientific note: reference entries are illustrative, not a complete database. Confirm disease diagnoses with validated tests or qualified specialists.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
