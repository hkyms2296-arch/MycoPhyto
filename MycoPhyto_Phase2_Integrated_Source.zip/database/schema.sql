-- MycoPhyto PostgreSQL foundation schema v1.0
-- Provenance-first: do not invent missing dates, countries, authors or DOIs.
CREATE TABLE IF NOT EXISTS fungi (
 id TEXT PRIMARY KEY, scientific_name TEXT NOT NULL, common_name_en TEXT,
 taxonomic_group TEXT, class_name TEXT, scientific_note TEXT,
 data_status TEXT NOT NULL DEFAULT 'needs_verification',
 verification_note TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS fungi_scientific_name_uq ON fungi (lower(scientific_name));
CREATE TABLE IF NOT EXISTS host_plants (
 id BIGSERIAL PRIMARY KEY, scientific_name TEXT NOT NULL UNIQUE, common_name TEXT
);
CREATE TABLE IF NOT EXISTS fungus_hosts (
 fungus_id TEXT NOT NULL REFERENCES fungi(id) ON DELETE CASCADE,
 host_id BIGINT NOT NULL REFERENCES host_plants(id) ON DELETE CASCADE,
 host_relationship TEXT NOT NULL DEFAULT 'reported_host', evidence_note TEXT,
 PRIMARY KEY (fungus_id, host_id)
);
CREATE TABLE IF NOT EXISTS fungus_content (
 fungus_id TEXT PRIMARY KEY REFERENCES fungi(id) ON DELETE CASCADE,
 symptoms TEXT, life_cycle TEXT, diagnosis TEXT, management TEXT
);
CREATE TABLE IF NOT EXISTS historical_taxonomy_events (
 id BIGSERIAL PRIMARY KEY, fungus_id TEXT NOT NULL REFERENCES fungi(id) ON DELETE CASCADE,
 event_type TEXT NOT NULL CHECK (event_type IN ('first_observation','first_isolation','formal_description','first_country_record','other')),
 event_year INTEGER CHECK (event_year BETWEEN 1600 AND 2100), location_text TEXT,
 researcher_or_author TEXT, publication_title TEXT, doi TEXT, source_url TEXT, notes TEXT,
 verification_status TEXT NOT NULL DEFAULT 'unverified', verified_at DATE,
 CHECK (doi IS NOT NULL OR source_url IS NOT NULL OR publication_title IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS country_occurrences (
 id BIGSERIAL PRIMARY KEY, fungus_id TEXT NOT NULL REFERENCES fungi(id) ON DELETE CASCADE,
 country_name TEXT NOT NULL, country_iso3 CHAR(3), record_year INTEGER CHECK (record_year BETWEEN 1600 AND 2100),
 locality TEXT, researcher_or_collector TEXT, publication_title TEXT, doi TEXT, source_url TEXT,
 occurrence_basis TEXT NOT NULL DEFAULT 'published_record',
 verification_status TEXT NOT NULL DEFAULT 'unverified', verified_at DATE, notes TEXT,
 CHECK (doi IS NOT NULL OR source_url IS NOT NULL OR publication_title IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS country_occurrences_fungus_idx ON country_occurrences(fungus_id);
CREATE INDEX IF NOT EXISTS country_occurrences_country_idx ON country_occurrences(country_name);
CREATE TABLE IF NOT EXISTS scientific_references (
 id BIGSERIAL PRIMARY KEY, fungus_id TEXT REFERENCES fungi(id) ON DELETE CASCADE,
 source_name TEXT NOT NULL, title TEXT, authors TEXT, publication_year INTEGER,
 doi TEXT, url TEXT, source_type TEXT, accessed_at DATE,
 verification_status TEXT NOT NULL DEFAULT 'unverified', notes TEXT,
 CHECK (doi IS NOT NULL OR url IS NOT NULL OR title IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS infected_plant_parts (
 id BIGSERIAL PRIMARY KEY, part_name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS fungus_plant_parts (
 fungus_id TEXT NOT NULL REFERENCES fungi(id) ON DELETE CASCADE,
 part_id BIGINT NOT NULL REFERENCES infected_plant_parts(id) ON DELETE CASCADE,
 evidence_note TEXT, PRIMARY KEY (fungus_id, part_id)
);
