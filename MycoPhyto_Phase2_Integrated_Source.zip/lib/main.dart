import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const MycoPhytoApp());

class MycoPhytoApp extends StatefulWidget {
  const MycoPhytoApp({super.key});
  @override
  State<MycoPhytoApp> createState() => _MycoPhytoAppState();
}

class _MycoPhytoAppState extends State<MycoPhytoApp> {
  bool english = false;
  int tab = 4;
  final Color green = const Color(0xFF176B43);

  @override
  Widget build(BuildContext context) {
    final pages = [
      LabPage(english: english),
      DistributionPage(english: english),
      PhotoPage(english: english),
      EncyclopediaPage(english: english),
      HomePage(english: english, onLanguage: () => setState(() => english = !english), onOpen: (i) => setState(() => tab = i)),
    ];
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MycoPhyto',
      theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: const Color(0xFFF4F8F3), appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF4F8F3), foregroundColor: Color(0xFF173D2A)), fontFamily: 'Roboto'),
      home: Directionality(
        textDirection: english ? TextDirection.ltr : TextDirection.rtl,
        child: Scaffold(
          body: IndexedStack(index: tab, children: pages),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            backgroundColor: const Color(0xFFEDF2EA), indicatorColor: const Color(0xFFD4EAD6),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.science_outlined), label: english ? 'References' : 'المراجع'),
              NavigationDestination(icon: const Icon(Icons.public), label: english ? 'Distribution' : 'خريطة الانتشار'),
              NavigationDestination(icon: const Icon(Icons.camera_alt_outlined), label: english ? 'Photo' : 'فحص صورة'),
              NavigationDestination(icon: const Icon(Icons.menu_book_outlined), label: english ? 'Encyclopedia' : 'الموسوعة'),
              NavigationDestination(icon: const Icon(Icons.home_outlined), label: english ? 'Home' : 'الرئيسية'),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final bool english; final VoidCallback onLanguage; final ValueChanged<int> onOpen;
  const HomePage({super.key, required this.english, required this.onLanguage, required this.onOpen});
  @override
  Widget build(BuildContext context) {
    final t = english;
    return SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 24), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [TextButton(onPressed: onLanguage, child: Text(t ? 'العربية' : 'English', style: const TextStyle(fontSize: 17, color: Color(0xFF356A4C)))), const Text('MycoPhyto', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 16), ClipRRect(borderRadius: BorderRadius.circular(26), child: Image.asset('assets/mycophyto_logo.jpg', height: 300, fit: BoxFit.cover)),
      const SizedBox(height: 22), Text(t ? 'Plant fungi scientific encyclopedia' : 'موسوعة علمية لتعريف وفهم فطريات النباتات', textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, height: 1.45, fontWeight: FontWeight.w600)),
      const SizedBox(height: 18),
      _HomeButton(icon: Icons.menu_book, label: t ? 'Fungal encyclopedia' : 'موسوعة الفطريات', onTap: () => onOpen(3)),
      _HomeButton(icon: Icons.camera_alt, label: t ? 'Choose a photo for examination' : 'اختيار صورة للفحص', onTap: () => onOpen(2)),
      _HomeButton(icon: Icons.public, label: t ? 'Distribution records' : 'خريطة الانتشار حسب السجلات', onTap: () => onOpen(1)),
      _HomeButton(icon: Icons.science, label: t ? 'Scientific references' : 'المراجع العلمية', onTap: () => onOpen(0)),
      const SizedBox(height: 12),
      Text(t ? 'Scientific notice: this version organizes reference information and stores selected photos. It does not diagnose diseases automatically.' : 'تنبيه علمي: هذه النسخة تنظّم المعلومات المرجعية وتحفظ الصور المختارة، لكنها لا تشخّص الأمراض آلياً.', style: const TextStyle(color: Colors.black54, height: 1.5)),
    ]));
  }
}

class _HomeButton extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _HomeButton({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(elevation: 1, color: const Color(0xFFF0F4ED), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12), leading: Icon(icon, color: const Color(0xFF3E9A5A), size: 29), title: Text(label, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w500)), trailing: const Icon(Icons.chevron_right), onTap: onTap)));
}

class Fungus {
  final String id, name, common, group, phylum, hosts, symptoms, lifecycle, diagnosis, management, note;
  final String dataStatus;
  const Fungus({
    required this.id, required this.name, required this.common,
    required this.group, required this.phylum, required this.hosts,
    required this.symptoms, required this.lifecycle, required this.diagnosis,
    required this.management, required this.note, required this.dataStatus,
  });

  factory Fungus.fromJson(Map<String, dynamic> json) {
    final hostList = (json['hosts'] as List<dynamic>? ?? const [])
        .map((item) => item.toString()).toList();
    return Fungus(
      id: (json['id'] ?? '').toString(),
      name: (json['scientific_name'] ?? '').toString(),
      common: (json['common_name_en'] ?? '').toString(),
      group: (json['taxonomic_group'] ?? '').toString(),
      phylum: (json['class_name'] ?? '').toString(),
      hosts: hostList.join(', '),
      symptoms: (json['symptoms'] ?? '').toString(),
      lifecycle: (json['life_cycle'] ?? '').toString(),
      diagnosis: (json['diagnosis'] ?? '').toString(),
      management: (json['management'] ?? '').toString(),
      note: (json['scientific_note'] ?? '').toString(),
      dataStatus: (json['data_status'] ?? 'needs_verification').toString(),
    );
  }
}

class FungusRepository {
  static Future<List<Fungus>> loadLocal() async {
    final raw = await rootBundle.loadString('database/fungi_seed.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    final records = decoded['records'] as List<dynamic>? ?? const [];
    return records
        .whereType<Map<String, dynamic>>()
        .map(Fungus.fromJson)
        .where((fungus) => fungus.name.isNotEmpty)
        .toList(growable: false);
  }
}

class EncyclopediaPage extends StatefulWidget {
  final bool english; const EncyclopediaPage({super.key, required this.english});
  @override State<EncyclopediaPage> createState() => _EncyclopediaPageState();
}
class _EncyclopediaPageState extends State<EncyclopediaPage> {
  final search = TextEditingController();
  String filter = 'All';
  late Future<List<Fungus>> recordsFuture;

  @override
  void initState() {
    super.initState();
    recordsFuture = FungusRepository.loadLocal();
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.english;
    final q = search.text.trim().toLowerCase();
    return Scaffold(
      appBar: AppBar(title: Text(t ? 'Fungal encyclopedia' : 'موسوعة الفطريات')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
          child: TextField(
            controller: search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: t ? 'Search scientific name, common name or host' : 'ابحث بالاسم العلمي أو الشائع أو العائل',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            for (final x in ['All', 'Fungi', 'Mushrooms'])
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(t ? x : (x == 'All' ? 'الكل' : x == 'Fungi' ? 'الفطريات الممرضة' : 'عيش الغراب')),
                  selected: filter == x,
                  onSelected: (_) => setState(() => filter = x),
                ),
              ),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<Fungus>>(
            future: recordsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(t
                      ? 'Could not load the local fungus database. Check the bundled JSON asset.'
                      : 'تعذر تحميل قاعدة بيانات الفطريات المحلية. تحقق من تضمين ملف JSON ضمن أصول التطبيق.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }
              final allRecords = snapshot.data ?? const <Fungus>[];
              final results = allRecords.where((f) {
                final isMushroom = f.name == 'Agaricus bisporus';
                final matchesFilter = filter == 'All' ||
                    (filter == 'Fungi' && !isMushroom) ||
                    (filter == 'Mushrooms' && isMushroom);
                final searchable = '${f.name} ${f.common} ${f.hosts}'.toLowerCase();
                return matchesFilter && searchable.contains(q);
              }).toList();

              if (results.isEmpty) {
                return Center(child: Text(t ? 'No matching records' : 'لا توجد سجلات مطابقة'));
              }
              return ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  Text(t ? '${results.length} local database records' : '${results.length} سجلات من قاعدة البيانات المحلية',
                    style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 8),
                  for (final f in results)
                    Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(14),
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFFDCEFE0),
                          child: Icon(Icons.biotech, color: Color(0xFF176B43)),
                        ),
                        title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${f.common}\n${f.group} · ${f.hosts}',
                          maxLines: 3, overflow: TextOverflow.ellipsis),
                        isThreeLine: true,
                        onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => FungusDetail(fungus: f, english: t))),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ]),
    );
  }
}

class FungusDetail extends StatelessWidget {
  final Fungus fungus; final bool english;
  const FungusDetail({super.key, required this.fungus, required this.english});
  @override Widget build(BuildContext context) {
    final t = english;
    final rows = <(String,String)>[
      (t ? 'Common name' : 'الاسم الشائع', fungus.common), (t ? 'Kingdom' : 'المملكة', 'Fungi'), (t ? 'Phylum' : 'الشعبة', fungus.group), (t ? 'Class' : 'الصف', fungus.phylum),
      (t ? 'Hosts' : 'العوائل النباتية', fungus.hosts), (t ? 'Symptoms' : 'الأعراض', fungus.symptoms), (t ? 'Life cycle and spread' : 'دورة الحياة والانتشار', fungus.lifecycle), (t ? 'Laboratory identification' : 'التشخيص المختبري', fungus.diagnosis), (t ? 'Management' : 'الإدارة والمكافحة', fungus.management),
      (t ? 'Historical description' : 'الاكتشاف والوصف الأول', t ? 'Not verified in this release. No author, year or place is asserted without a traceable taxonomic source.' : 'غير موثق في هذا الإصدار. لا نذكر اسم واصف أو سنة أو مكان دون مصدر تصنيفي قابل للتحقق.'),
      (t ? 'Country distribution' : 'التوزيع حسب الدول', t ? 'Country-level records are not yet integrated. A country must only be listed when supported by a published or curated occurrence record.' : 'لم تُدمج سجلات الدول بعد. لا تُدرج دولة إلا بوجود سجل انتشار منشور أو موثق.'), (t ? 'Scientific note' : 'ملاحظة علمية', fungus.note),
    ];
    return Scaffold(appBar: AppBar(title: Text(t ? 'Record details' : 'تفاصيل السجل')), body: ListView(padding: const EdgeInsets.all(18), children: [Text(fungus.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 8), for (final r in rows) _DetailRow(r.$1, r.$2)]));
  }
}
class _DetailRow extends StatelessWidget { final String title, value; const _DetailRow(this.title,this.value); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF176B43))), const SizedBox(height: 5), Text(value, style: const TextStyle(height: 1.45))])); }

class PhotoPage extends StatefulWidget { final bool english; const PhotoPage({super.key, required this.english}); @override State<PhotoPage> createState() => _PhotoPageState(); }
class _PhotoPageState extends State<PhotoPage> {
  File? image; List<String> saved = []; final picker = ImagePicker(); bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final p = await SharedPreferences.getInstance(); if (!mounted) return; setState(() { saved = p.getStringList('mycophyto_saved_photos') ?? []; loading = false; }); }
  Future<void> choose(ImageSource source) async {
    try {
      final x = await picker.pickImage(source: source, imageQuality: 88, maxWidth: 1800);
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final folder = Directory('${dir.path}/mycophyto_photos'); await folder.create(recursive: true);
      final target = '${folder.path}/photo_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final copied = await File(x.path).copy(target);
      final p = await SharedPreferences.getInstance(); saved.insert(0, copied.path); await p.setStringList('mycophyto_saved_photos', saved);
      if (!mounted) return; setState(() => image = copied); _message(widget.english ? 'Photo saved on this device.' : 'تم حفظ الصورة على هذا الجهاز.');
    } catch (_) { if (mounted) _message(widget.english ? 'Could not open or save the photo.' : 'تعذر فتح الصورة أو حفظها.'); }
  }
  Future<void> remove(String path) async { try { final f = File(path); if (await f.exists()) await f.delete(); } catch (_) {} saved.remove(path); final p = await SharedPreferences.getInstance(); await p.setStringList('mycophyto_saved_photos', saved); if (mounted) setState(() { if (image?.path == path) image = null; }); }
  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override Widget build(BuildContext context) {
    final t = widget.english;
    return Scaffold(appBar: AppBar(title: Text(t ? 'Photo examination' : 'فحص صورة نبات أو فطر')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(t ? 'Choose a clear image of a leaf, stem, fruit or microscopic specimen.' : 'اختر صورة واضحة للورقة أو الساق أو الثمرة أو العينة المجهرية.', style: const TextStyle(fontSize: 17, height: 1.5)), const SizedBox(height: 14),
        Row(children: [Expanded(child: FilledButton.icon(onPressed: () => choose(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: Text(t ? 'Camera' : 'الكاميرا'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () => choose(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: Text(t ? 'Gallery' : 'المعرض')))]),
        if (image != null) ...[const SizedBox(height: 16), ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(image!, fit: BoxFit.contain)), const SizedBox(height: 8), Text(t ? 'Saved locally' : 'محفوظة على الجهاز', style: const TextStyle(color: Color(0xFF176B43), fontWeight: FontWeight.bold))],
        const SizedBox(height: 18), Card(child: Padding(padding: const EdgeInsets.all(15), child: Text(t ? 'Important: this app does not identify pathogens from images. Use laboratory or validated diagnostic methods before making crop-protection decisions.' : 'تنبيه مهم: التطبيق لا يحدد الممرضات من الصور. استخدم الفحص المختبري أو طرق تشخيص متحققاً منها قبل اتخاذ قرارات المكافحة.', style: const TextStyle(height: 1.5)))),
        const SizedBox(height: 14), Text(t ? 'Saved photo history (${saved.length})' : 'سجل الصور المحفوظة (${saved.length})', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        if (loading) const Center(child: CircularProgressIndicator()) else if (saved.isEmpty) Text(t ? 'No saved photos yet.' : 'لا توجد صور محفوظة حالياً.') else for (final path in saved) Card(child: ListTile(leading: const Icon(Icons.image_outlined), title: Text(path.split('/').last), onTap: () => setState(() => image = File(path)), trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => remove(path)))),
      ]));
  }
}

class DistributionPage extends StatelessWidget { final bool english; const DistributionPage({super.key, required this.english});
  @override Widget build(BuildContext context) { final t = english; return Scaffold(appBar: AppBar(title: Text(t ? 'Distribution records' : 'خريطة الانتشار')), body: ListView(padding: const EdgeInsets.all(20), children: [const Icon(Icons.public, size: 80, color: Color(0xFF2E8B57)), Text(t ? 'Documented global occurrence' : 'سجلات الانتشار العالمي الموثقة', textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 14), Text(t ? 'An interactive map is not included yet. This section is prepared for country records containing the country, collector or researcher, publication year, source or DOI, and verification date.' : 'الخريطة التفاعلية غير مضافة بعد. هذا القسم مهيأ لسجلات الدول التي تتضمن الدولة والباحث أو جامع العينة وسنة النشر والمصدر أو DOI وتاريخ التحقق.', style: const TextStyle(height: 1.6)), const SizedBox(height: 14), Text(t ? 'Recommended sources' : 'مصادر مقترحة', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 8), const _ReferenceLink(name: 'GBIF', url: 'https://www.gbif.org/'), const _ReferenceLink(name: 'EPPO Global Database', url: 'https://gd.eppo.int/'), const _ReferenceLink(name: 'MycoBank', url: 'https://www.mycobank.org/'), const _ReferenceLink(name: 'Index Fungorum', url: 'https://www.indexfungorum.org/'), const _ReferenceLink(name: 'NCBI Taxonomy', url: 'https://www.ncbi.nlm.nih.gov/taxonomy'),])); }
}

class LabPage extends StatelessWidget { final bool english; const LabPage({super.key, required this.english});
  @override Widget build(BuildContext context) { final t = english; return Scaffold(appBar: AppBar(title: Text(t ? 'Scientific references' : 'المراجع العلمية')), body: ListView(padding: const EdgeInsets.all(18), children: [Text(t ? 'Open trusted databases for taxonomy, occurrence records and plant-health information.' : 'افتح قواعد البيانات الموثوقة للتصنيف وسجلات الانتشار ومعلومات صحة النبات.', style: const TextStyle(height: 1.5)), const SizedBox(height: 12), const _ReferenceLink(name: 'Index Fungorum', description: 'Fungal names and nomenclature', url: 'https://www.indexfungorum.org/'), const _ReferenceLink(name: 'MycoBank', description: 'Fungal nomenclatural database', url: 'https://www.mycobank.org/'), const _ReferenceLink(name: 'GBIF', description: 'Biodiversity occurrence records', url: 'https://www.gbif.org/'), const _ReferenceLink(name: 'EPPO Global Database', description: 'Plant pests and distribution', url: 'https://gd.eppo.int/'), const _ReferenceLink(name: 'NCBI Taxonomy', description: 'Organism taxonomy and sequence links', url: 'https://www.ncbi.nlm.nih.gov/taxonomy'), const SizedBox(height: 12), Text(t ? 'A database link is a research starting point, not proof that a particular species occurs in a particular country.' : 'رابط قاعدة البيانات نقطة بداية للبحث، وليس دليلاً وحده على وجود نوع معين في دولة محددة.', style: const TextStyle(color: Colors.black54, height: 1.5))])); }
}

class _ReferenceLink extends StatelessWidget { final String name, url; final String? description; const _ReferenceLink({required this.name, required this.url, this.description});
  Future<void> _open(BuildContext context) async { final uri = Uri.parse(url); if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط'))); }
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: const Icon(Icons.open_in_new, color: Color(0xFF176B43)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: description == null ? null : Text(description!), onTap: () => _open(context)));
}
