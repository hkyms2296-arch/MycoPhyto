# MycoPhyto — Phase 2 integrated source

## What is included
- Flutter Android source with Arabic/English interface.
- Offline fungal encyclopedia loaded from `database/fungi_seed.json` through Flutter asset loading.
- Search/filter over local records; camera/gallery image selection and local history.
- PostgreSQL schema and seed records.
- FastAPI/SQLAlchemy backend source, GBIF importer and scientific data policy/model-card templates.
- GitHub Actions workflow using Java 21 to generate Android platform files, analyze Dart source and build a release APK.

## Build APK
Upload the **contents** of this folder to the root of the GitHub repository (not the outer folder). Then open Actions and run `Build MycoPhyto APK`. Check the Analyze and Build steps; a green workflow is required before installing the artifact.

## Honest feature status
- Offline local encyclopedia: implemented using the bundled JSON asset.
- Backend: source code and schema are included, but no hosted server or production PostgreSQL instance is deployed.
- Distribution map: not yet connected to reviewed georeferenced occurrence records; no country points are fabricated.
- AI diagnosis: not implemented. There is no trained model, weights or validation report; image selection is not AI diagnosis.
- Starter fungus records are not a comprehensive or fully verified scientific database. Verify taxonomy and literature before relying on them.

## Backend quick start
See `backend/README_AR.md`. By default it uses SQLite for local development. Set `DATABASE_URL` to a PostgreSQL connection string for deployment. The `/diagnose` endpoint deliberately returns a service-unavailable response until a validated model and inference adapter are installed.

## Package identity
The workflow currently generates the Android project with `--org com.mycophyto --project-name app`. Verify the final APK applicationId from the build logs/manifest before installation; do not assume it will update an older app with a different ID.
