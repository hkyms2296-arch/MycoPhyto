# MycoPhyto AI Model Card — template (not a trained model)

- Model name/version:
- Intended use and excluded use:
- Supported crops / fungal taxa:
- Training dataset, licences and provenance:
- Number of images per class:
- Annotation protocol and expert reviewers:
- Train/validation/test split method:
- External field test sites and dates:
- Per-class precision, recall, F1 and confusion matrix:
- Calibration / abstention threshold:
- Known limitations (cultivar, lighting, camera, mixed infections, abiotic stress):
- Model format, input size, preprocessing and runtime:
- Responsible maintainer and review date:

Release gate: do not enable user-facing diagnosis until the card is completed, independently evaluated, and signed off by plant pathology experts.
