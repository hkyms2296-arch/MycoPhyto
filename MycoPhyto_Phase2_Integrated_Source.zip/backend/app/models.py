from sqlalchemy import String, Text, Integer, Float, ForeignKey, DateTime, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from .database import Base

class Fungus(Base):
    __tablename__ = 'fungi'
    id: Mapped[int] = mapped_column(primary_key=True)
    scientific_name: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    accepted_name: Mapped[str | None] = mapped_column(String(255))
    common_name_en: Mapped[str | None] = mapped_column(String(255))
    common_name_ar: Mapped[str | None] = mapped_column(String(255))
    description_en: Mapped[str | None] = mapped_column(Text)
    description_ar: Mapped[str | None] = mapped_column(Text)
    kingdom: Mapped[str | None] = mapped_column(String(100))
    phylum: Mapped[str | None] = mapped_column(String(100))
    class_name: Mapped[str | None] = mapped_column(String(100))
    order_name: Mapped[str | None] = mapped_column(String(100))
    family: Mapped[str | None] = mapped_column(String(100))
    genus: Mapped[str | None] = mapped_column(String(100))
    species_epithet: Mapped[str | None] = mapped_column(String(100))
    first_observation_note: Mapped[str | None] = mapped_column(Text)
    first_isolation_note: Mapped[str | None] = mapped_column(Text)
    formal_describer: Mapped[str | None] = mapped_column(String(255))
    description_year: Mapped[int | None] = mapped_column(Integer)
    nomenclatural_source: Mapped[str | None] = mapped_column(Text)
    verification_status: Mapped[str] = mapped_column(String(30), default='unverified')
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    hosts = relationship('Host', secondary='fungus_hosts', back_populates='fungi')
    occurrences = relationship('Occurrence', back_populates='fungus')
    references = relationship('Reference', back_populates='fungus')

class Host(Base):
    __tablename__ = 'hosts'
    id: Mapped[int] = mapped_column(primary_key=True)
    scientific_name: Mapped[str] = mapped_column(String(255), unique=True)
    common_name: Mapped[str | None] = mapped_column(String(255))
    fungi = relationship('Fungus', secondary='fungus_hosts', back_populates='hosts')

class FungusHost(Base):
    __tablename__ = 'fungus_hosts'
    fungus_id: Mapped[int] = mapped_column(ForeignKey('fungi.id', ondelete='CASCADE'), primary_key=True)
    host_id: Mapped[int] = mapped_column(ForeignKey('hosts.id', ondelete='CASCADE'), primary_key=True)
    host_part: Mapped[str | None] = mapped_column(String(120))
    pathogenicity: Mapped[str | None] = mapped_column(Text)

class Symptom(Base):
    __tablename__ = 'symptoms'
    id: Mapped[int] = mapped_column(primary_key=True)
    fungus_id: Mapped[int] = mapped_column(ForeignKey('fungi.id', ondelete='CASCADE'), index=True)
    plant_part: Mapped[str | None] = mapped_column(String(120))
    symptom_en: Mapped[str | None] = mapped_column(Text)
    symptom_ar: Mapped[str | None] = mapped_column(Text)

class Occurrence(Base):
    __tablename__ = 'occurrences'
    __table_args__ = (UniqueConstraint('fungus_id','source','source_record_id', name='uq_occ_source_record'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    fungus_id: Mapped[int] = mapped_column(ForeignKey('fungi.id', ondelete='CASCADE'), index=True)
    country_code: Mapped[str | None] = mapped_column(String(2), index=True)
    country_name: Mapped[str | None] = mapped_column(String(120))
    latitude: Mapped[float | None] = mapped_column(Float)
    longitude: Mapped[float | None] = mapped_column(Float)
    event_year: Mapped[int | None] = mapped_column(Integer)
    recorded_by: Mapped[str | None] = mapped_column(String(255))
    identified_by: Mapped[str | None] = mapped_column(String(255))
    basis_of_record: Mapped[str | None] = mapped_column(String(100))
    source: Mapped[str] = mapped_column(String(80))
    source_record_id: Mapped[str] = mapped_column(String(160))
    citation: Mapped[str | None] = mapped_column(Text)
    source_url: Mapped[str | None] = mapped_column(Text)
    verification_status: Mapped[str] = mapped_column(String(30), default='needs_review')
    fungus = relationship('Fungus', back_populates='occurrences')

class Reference(Base):
    __tablename__ = 'references'
    id: Mapped[int] = mapped_column(primary_key=True)
    fungus_id: Mapped[int | None] = mapped_column(ForeignKey('fungi.id', ondelete='SET NULL'), index=True)
    title: Mapped[str] = mapped_column(Text)
    authors: Mapped[str | None] = mapped_column(Text)
    publication_year: Mapped[int | None] = mapped_column(Integer)
    doi: Mapped[str | None] = mapped_column(String(255))
    url: Mapped[str | None] = mapped_column(Text)
    source_type: Mapped[str | None] = mapped_column(String(80))
    fungus = relationship('Fungus', back_populates='references')

class DiagnosisJob(Base):
    __tablename__ = 'diagnosis_jobs'
    id: Mapped[int] = mapped_column(primary_key=True)
    image_sha256: Mapped[str] = mapped_column(String(64), index=True)
    model_version: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(30), default='pending')
    predicted_label: Mapped[str | None] = mapped_column(String(255))
    confidence: Mapped[float | None] = mapped_column(Float)
    created_at = mapped_column(DateTime(timezone=True), server_default=func.now())
