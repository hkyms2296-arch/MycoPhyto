"""Import GBIF occurrence records into MycoPhyto as needs_review, never auto-verified.
Usage: python import_gbif.py 'Puccinia graminis' --limit 100
Requires backend requirements and DATABASE_URL configured.
"""
import argparse, requests
from sqlalchemy import select
from app.database import SessionLocal
from app.models import Fungus, Occurrence

parser = argparse.ArgumentParser()
parser.add_argument('taxon_name')
parser.add_argument('--limit', type=int, default=100)
args = parser.parse_args()

with SessionLocal() as db:
    fungus = db.scalar(select(Fungus).where(Fungus.scientific_name.ilike(args.taxon_name)))
    if not fungus:
        fungus = Fungus(scientific_name=args.taxon_name, verification_status='needs_review')
        db.add(fungus); db.commit(); db.refresh(fungus)
    match = requests.get('https://api.gbif.org/v1/species/match', params={'name':args.taxon_name}, timeout=30).json()
    key = match.get('usageKey')
    if not key: raise SystemExit('GBIF taxon match not found; review name manually.')
    data = requests.get('https://api.gbif.org/v1/occurrence/search', params={'taxonKey':key,'limit':min(args.limit,300),'hasCoordinate':'true'}, timeout=60).json()
    added = 0
    for item in data.get('results', []):
        gbif_id = str(item.get('key'))
        exists = db.scalar(select(Occurrence).where(Occurrence.fungus_id==fungus.id, Occurrence.source=='GBIF', Occurrence.source_record_id==gbif_id))
        if exists: continue
        db.add(Occurrence(fungus_id=fungus.id, country_code=item.get('countryCode'), country_name=item.get('country'), latitude=item.get('decimalLatitude'), longitude=item.get('decimalLongitude'), event_year=item.get('year'), recorded_by=item.get('recordedBy'), identified_by=item.get('identifiedBy'), basis_of_record=item.get('basisOfRecord'), source='GBIF', source_record_id=gbif_id, citation=item.get('publishingOrg') or item.get('datasetName'), source_url=f"https://www.gbif.org/occurrence/{gbif_id}", verification_status='needs_review'))
        added += 1
    db.commit()
    print(f'Imported {added} records as needs_review. Review taxonomy, coordinates, duplicates and citation before verification.')
