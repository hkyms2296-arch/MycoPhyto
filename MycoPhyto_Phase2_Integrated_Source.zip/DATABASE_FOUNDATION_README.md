# MycoPhyto v1.3.1 – Database Foundation

This is an incremental extension of the supplied v1.3 Flutter source. Existing UI, logo, and Android workflow are preserved.

## Added
- `database/schema.sql`: PostgreSQL schema for fungi, host plants, infected plant parts, historical taxonomic events, country occurrence records and scientific references.
- `database/fungi_seed.json`: structured migration of the four starter records in `lib/main.dart`.

## Data integrity
- Historical events, country occurrences and references are empty until verified sources are entered. No dates, authors, countries or DOIs were fabricated.
- Seed records are marked `starter_record_unverified`.
- `Agaricus bisporus` remains a cultivated mushroom reference, not a plant pathogen.
- `Fusarium oxysporum species complex` remains at complex level.

## Not yet implemented
- Flutter does not yet load this JSON asset.
- No deployed PostgreSQL database or FastAPI service is included.
- No interactive map or trained image diagnosis model is included.

## Next integration
1. Add Flutter repository layer and load local JSON.
2. Add FastAPI endpoints and database migrations.
3. Ingest sourced occurrence records with provenance.
4. Connect map UI to verified records.
5. Train and validate a labeled image model before on-device inference.

Prepared from the user-supplied `MycoPhyto_v1.3_Source_Improved-1.zip`.

## v1.3.1 local Flutter integration update
The encyclopedia now loads `database/fungi_seed.json` through Flutter asset loading (`rootBundle`) and JSON decoding. Search and category filters operate on the loaded records. This works offline. The PostgreSQL schema remains a server-side foundation and is not connected to a deployed backend.
