# MycoPhyto v1.2 — Flutter source project

## ما الذي تطور في v1.2؟
- الحفاظ على هوية MycoPhyto والشعار والواجهة الرئيسية.
- دعم العربية والإنكليزية مع اتجاه RTL/LTR.
- بحث داخل الموسوعة بالاسم العلمي أو الشائع أو العائل، مع تصفية السجلات.
- صفحات تفاصيل موسعة: التصنيف، العوائل، الأعراض، دورة الحياة، التشخيص المختبري والإدارة.
- اختيار الصور بالكاميرا أو المعرض، ونسخها إلى مساحة التطبيق الخاصة حتى تبقى محفوظة بعد إغلاق التطبيق.
- سجل محلي للصور المحفوظة مع إمكانية فتح الصورة أو حذفها.
- روابط قابلة للفتح لقواعد Index Fungorum وMycoBank وGBIF وEPPO وNCBI.
- تحديث إصدار التطبيق إلى 1.2.0+3، وتحديث GitHub Actions إلى Java 21 مع تحليل Flutter قبل بناء APK.

## ما الذي لم يُنفذ بعد؟
- لا يوجد نموذج ذكاء اصطناعي مدرّب ومتحقق منه لتشخيص الأمراض من الصور.
- لا توجد خريطة عالمية تفاعلية أو سجلات انتشار قطرية موثقة مدمجة.
- البيانات العلمية في الموسوعة سجلات تمهيدية وليست قاعدة بيانات شاملة. معلومات الواصف الأول وتاريخ الوصف والتوزيع حسب الدول تبقى غير مؤكدة ما لم تُربط بمصدر أصلي أو سجل موثوق.
- روابط قواعد البيانات تفتح مواقعها، لكنها لا تعني أن بياناتها جرى استيرادها أو مزامنتها داخل التطبيق.

## Build
1. Extract the project ZIP.
2. Run `flutter create --platforms=android --org com.mycophyto --project-name mycophyto .`
3. Run `flutter pub get`.
4. Run `flutter analyze`.
5. Run `flutter build apk --release`.

GitHub Actions workflow: `.github/workflows/android.yml`.

## Important
This version is a scientific reference and photo-recording tool, not an automated plant disease diagnostic system. Confirm diagnoses using validated laboratory methods and qualified plant-health specialists. Do not use app content alone to select pesticide treatments.
