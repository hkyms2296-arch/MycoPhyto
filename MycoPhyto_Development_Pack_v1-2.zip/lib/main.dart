import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MycoPhytoApp());

class MycoPhytoApp extends StatefulWidget {
  const MycoPhytoApp({super.key});
  @override
  State<MycoPhytoApp> createState() => _MycoPhytoAppState();
}

class _MycoPhytoAppState extends State<MycoPhytoApp> {
  bool english = false;
  int tab = 4;
  final Color green = const Color(0xFF176B43);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MycoPhyto',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF4F8F3),
        fontFamily: 'Roboto',
      ),
      home: Directionality(
        textDirection: english ? TextDirection.ltr : TextDirection.rtl,
        child: Scaffold(
          body: IndexedStack(
            index: tab,
            children: [
              const LabPage(),
              const DistributionPage(),
              const PhotoPage(),
              const EncyclopediaPage(),
              HomePage(
                english: english,
                onLanguage: () => setState(() => english = !english),
                onOpen: (i) => setState(() => tab = i),
              ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            backgroundColor: const Color(0xFFEDF2EA),
            indicatorColor: const Color(0xFFD4EAD6),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.science_outlined), label: english ? 'Lab' : 'المراجع'),
              NavigationDestination(icon: const Icon(Icons.public), label: english ? 'Map' : 'خريطة الانتشار'),
              NavigationDestination(icon: const Icon(Icons.camera_alt_outlined), label: english ? 'Photo' : 'فحص صورة'),
              NavigationDestination(icon: const Icon(Icons.menu_book_outlined), label: english ? 'Fungi' : 'الموسوعة'),
              NavigationDestination(icon: const Icon(Icons.home_outlined), label: english ? 'Home' : 'الرئيسية'),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final bool english;
  final VoidCallback onLanguage;
  final ValueChanged<int> onOpen;
  const HomePage({super.key, required this.english, required this.onLanguage, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final t = english;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(onPressed: onLanguage, child: Text(t ? 'العربية' : 'English', style: const TextStyle(fontSize: 17, color: Color(0xFF356A4C)))),
              const Text('MycoPhyto', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Image.asset('assets/mycophyto_logo.jpg', height: 300, fit: BoxFit.cover),
          ),
          const SizedBox(height: 22),
          Text(t ? 'Scientific encyclopedia for plant fungi identification' : 'موسوعة علمية لتعريف وفهم فطريات النباتات',
            textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, height: 1.45, fontWeight: FontWeight.w600)),
          const SizedBox(height: 18),
          _HomeButton(icon: Icons.menu_book, label: t ? 'Fungal encyclopedia' : 'موسوعة الفطريات', onTap: () => onOpen(3)),
          _HomeButton(icon: Icons.camera_alt, label: t ? 'Choose a photo for examination' : 'اختيار صورة للفحص', onTap: () => onOpen(2)),
          _HomeButton(icon: Icons.public, label: t ? 'Distribution map by records' : 'خريطة الانتشار حسب السجلات', onTap: () => onOpen(1)),
          _HomeButton(icon: Icons.science, label: t ? 'Scientific references' : 'المراجع العلمية', onTap: () => onOpen(0)),
          const SizedBox(height: 12),
          Text(t
            ? 'Scientific notice: photo selection is available, but automated disease diagnosis requires a validated model and is not enabled in this build.'
            : 'تنبيه علمي: يمكن اختيار الصور، لكن التشخيص الآلي للأمراض يحتاج نموذجاً مدرّباً ومتحققاً من دقته، وهو غير مفعّل في هذه النسخة.',
            style: const TextStyle(color: Colors.black54, height: 1.5)),
        ],
      ),
    );
  }
}

class _HomeButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _HomeButton({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Card(
      elevation: 1,
      color: const Color(0xFFF0F4ED),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        leading: Icon(icon, color: const Color(0xFF3E9A5A), size: 29),
        title: Text(label, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w500)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    ),
  );
}

class Fungus {
  final String name, common, group, hosts, symptoms, note;
  const Fungus(this.name, this.common, this.group, this.hosts, this.symptoms, this.note);
}

const fungi = [
  Fungus('Botrytis cinerea', 'Gray mold fungus', 'Ascomycota', 'Tomato, grape, strawberry and many hosts', 'Soft rot, gray sporulation and water-soaked lesions', 'Identification should be confirmed by microscopy or a validated laboratory method.'),
  Fungus('Puccinia graminis', 'Stem rust', 'Basidiomycota', 'Wheat and other grasses', 'Reddish-brown elongated pustules on stems and leaves', 'Record host, plant stage and field distribution when sampling.'),
  Fungus('Fusarium oxysporum species complex', 'Fusarium wilt pathogens', 'Ascomycota', 'Many crop hosts; formae speciales differ by host', 'Vascular discoloration, yellowing and wilt', 'Species-complex identification may require molecular testing.'),
  Fungus('Agaricus bisporus', 'Button mushroom', 'Basidiomycota', 'Cultivated compost substrate', 'Cultivated edible mushroom; not a plant pathogen', 'Do not use an app result to determine whether a wild mushroom is safe to eat.'),
];

class EncyclopediaPage extends StatelessWidget {
  const EncyclopediaPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('موسوعة الفطريات')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('سجلات مرجعية أولية — تحتاج بيانات التوثيق التاريخي والتوزيع إلى مراجعة المصادر قبل اعتمادها.', style: TextStyle(color: Colors.black54, height: 1.5)),
        const SizedBox(height: 12),
        for (final f in fungi)
          Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: const CircleAvatar(backgroundColor: Color(0xFFDCEFE0), child: Icon(Icons.biotech, color: Color(0xFF176B43))),
              title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${f.common}\n${f.group}', style: const TextStyle(height: 1.5)),
              isThreeLine: true,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FungusDetail(fungus: f))),
            ),
          ),
      ],
    ),
  );
}

class FungusDetail extends StatelessWidget {
  final Fungus fungus;
  const FungusDetail({super.key, required this.fungus});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تفاصيل الفطر')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Text(fungus.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(fungus.common, style: const TextStyle(fontSize: 18)),
      const Divider(height: 28),
      _DetailRow('المجموعة التصنيفية', fungus.group),
      _DetailRow('العوائل النباتية', fungus.hosts),
      _DetailRow('الأعراض', fungus.symptoms),
      _DetailRow('ملاحظة علمية', fungus.note),
      const _DetailRow('الاكتشاف والوصف الأول', 'غير موثق في هذه النسخة — لا تُعرض أسماء أو تواريخ دون مصدر أصلي.'),
      const _DetailRow('التوزيع حسب الدول', 'قيد بناء قاعدة سجلات موثقة مع اسم الباحث والسنة والرابط لكل دولة.'),
    ]),
  );
}

class _DetailRow extends StatelessWidget {
  final String title, value;
  const _DetailRow(this.title, this.value);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF176B43))),
      const SizedBox(height: 5),
      Text(value, style: const TextStyle(height: 1.45)),
    ]),
  );
}

class PhotoPage extends StatefulWidget {
  const PhotoPage({super.key});
  @override
  State<PhotoPage> createState() => _PhotoPageState();
}

class _PhotoPageState extends State<PhotoPage> {
  File? image;
  final picker = ImagePicker();
  Future<void> choose(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 88, maxWidth: 1800);
    if (x != null) setState(() => image = File(x.path));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('فحص صورة نبات أو فطر')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('اختر صورة واضحة للورقة أو الساق أو الثمرة أو العينة المجهرية.', style: TextStyle(fontSize: 18, height: 1.5)),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: () => choose(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('الكاميرا'))),
        const SizedBox(width: 10),
        Expanded(child: OutlinedButton.icon(onPressed: () => choose(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('المعرض'))),
      ]),
      const SizedBox(height: 18),
      if (image != null) ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(image!, fit: BoxFit.contain)),
      const SizedBox(height: 16),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('هذه النسخة تحفظ إمكانية اختيار الصورة فقط. لا تصدر تشخيصاً آلياً؛ يجب ربط نموذج مدرّب ومختبر قبل عرض اسم مسبب مرضي أو توصية علاجية.', style: TextStyle(height: 1.5)))),
    ]),
  );
}

class DistributionPage extends StatelessWidget {
  const DistributionPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('خريطة الانتشار')),
    body: ListView(padding: const EdgeInsets.all(20), children: const [
      Icon(Icons.public, size: 80, color: Color(0xFF2E8B57)),
      Text('قاعدة سجلات الانتشار العالمي', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 14),
      Text('سيُربط هذا القسم بخريطة تفاعلية بعد إدخال سجلات موثقة لكل دولة. يجب أن يحتوي كل سجل على الدولة، الباحث، سنة النشر، المرجع أو DOI، وتاريخ التحقق.', style: TextStyle(height: 1.6)),
      SizedBox(height: 12),
      Text('مصادر مقترحة: GBIF، EPPO، MycoBank، Index Fungorum، NCBI Taxonomy، والأبحاث المحكمة.', style: TextStyle(height: 1.6)),
      SizedBox(height: 12),
      Text('لا تُعرض دولة على الخريطة لمجرد أن الفطر معروف عالمياً؛ يلزم سجل موثق قابل للتتبع.', style: TextStyle(fontWeight: FontWeight.w600, height: 1.5)),
    ]),
  );
}

class LabPage extends StatelessWidget {
  const LabPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المراجع العلمية')),
    body: ListView(padding: const EdgeInsets.all(18), children: const [
      _ReferenceCard('Index Fungorum', 'قاعدة بيانات الأسماء والتصنيف الفطري.'),
      _ReferenceCard('MycoBank', 'قاعدة بيانات الأسماء والتسميات الفطرية.'),
      _ReferenceCard('GBIF', 'سجلات التنوع الحيوي والانتشار الجغرافي.'),
      _ReferenceCard('EPPO Global Database', 'معلومات الآفات النباتية وتوزيعها.'),
      _ReferenceCard('NCBI Taxonomy', 'التصنيف الحيوي المرتبط ببيانات التسلسل.'),
      SizedBox(height: 12),
      Text('يجب إضافة روابط مباشرة ومعرّفات DOI والتحقق من كل سجل قبل نشره.', style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class _ReferenceCard extends StatelessWidget {
  final String name, description;
  const _ReferenceCard(this.name, this.description);
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: const Icon(Icons.menu_book, color: Color(0xFF176B43)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(description)));
}
