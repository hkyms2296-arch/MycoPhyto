# MycoPhyto – Development Pack

This is a Flutter source starter aligned with the approved MycoPhyto home-screen design.

## Build
1. Extract this ZIP.
2. Run `flutter create --platforms=android --org com.mycophyto --project-name mycophyto .`
3. Run `flutter pub get`.
4. Run `flutter build apk --release`.

A GitHub Actions workflow is included at `.github/workflows/android.yml`.

## Included now
- Arabic-first home screen with Arabic/English toggle and RTL/LTR layout.
- Bottom navigation for home, encyclopedia, photo selection, distribution and references.
- Fungal reference cards and detail pages.
- Camera/gallery photo selection.
- Scientific caution labels: photo selection is not AI diagnosis.

## Not yet implemented
- No trained or validated image-diagnosis model.
- No real interactive world map or verified country-by-country occurrence dataset.
- No live database/API connection.
- Historical discovery/isolation/describer details are intentionally marked unverified until supported by primary references.

Do not use this build for clinical/agricultural diagnosis or treatment decisions without expert confirmation.
