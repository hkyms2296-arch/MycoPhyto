import hashlib, os
from fastapi import FastAPI, Depends, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from .database import Base, engine, get_db
from .models import Fungus, Occurrence, Reference

Base.metadata.create_all(bind=engine)
app = FastAPI(title='MycoPhyto Scientific API', version='0.2.0', description='Fungal taxonomy, documented occurrence records and validated image inference.')
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CORS_ORIGINS','*').split(','), allow_methods=['*'], allow_headers=['*'])

@app.get('/health')
def health(): return {'status':'ok','api_version':'0.2.0'}


@app.get('/integrations/mycobank/link')
def mycobank_link(name: str | None = None, number: int | None = None):
    """Build official MycoBank links; live webservice access requires permission from MycoBank."""
    if not name and number is None:
        raise HTTPException(400, 'Provide a fungal name or MycoBank number')
    if number is not None:
        if number <= 0:
            raise HTTPException(400, 'MycoBank number must be positive')
        return {'source': 'MycoBank', 'record_type': 'number', 'identifier': number,
                'url': f'https://www.mycobank.org/MB/{number}',
                'automated_data_access': 'contact_required'}
    cleaned = ' '.join(name.strip().split())
    if not cleaned or len(cleaned) > 255:
        raise HTTPException(400, 'Name must contain 1 to 255 characters')
    from urllib.parse import quote
    return {'source': 'MycoBank', 'record_type': 'name', 'identifier': cleaned,
            'url': 'https://www.mycobank.org/name/' + quote(cleaned, safe=''),
            'automated_data_access': 'contact_required'}

@app.get('/fungi')
def list_fungi(q: str | None = None, db: Session = Depends(get_db)):
    stmt = select(Fungus)
    if q: stmt = stmt.where(Fungus.scientific_name.ilike(f'%{q}%'))
    return [{'id':x.id,'scientific_name':x.scientific_name,'accepted_name':x.accepted_name,'common_name_en':x.common_name_en,'common_name_ar':x.common_name_ar,'verification_status':x.verification_status} for x in db.scalars(stmt.order_by(Fungus.scientific_name)).all()]

@app.get('/fungi/{fungus_id}')
def fungus_detail(fungus_id: int, db: Session = Depends(get_db)):
    f = db.get(Fungus, fungus_id)
    if not f: raise HTTPException(404, 'Fungus not found')
    return {'id':f.id,'scientific_name':f.scientific_name,'accepted_name':f.accepted_name,'description_en':f.description_en,'description_ar':f.description_ar,'taxonomy':{'kingdom':f.kingdom,'phylum':f.phylum,'class':f.class_name,'order':f.order_name,'family':f.family,'genus':f.genus},'history':{'first_observation':f.first_observation_note,'first_isolation':f.first_isolation_note,'formal_describer':f.formal_describer,'description_year':f.description_year},'verification_status':f.verification_status}

@app.get('/occurrences')
def occurrences(fungus_id: int | None = None, country: str | None = None, verified_only: bool = True, db: Session = Depends(get_db)):
    stmt = select(Occurrence)
    if fungus_id is not None: stmt = stmt.where(Occurrence.fungus_id == fungus_id)
    if country: stmt = stmt.where(Occurrence.country_code == country.upper())
    if verified_only: stmt = stmt.where(Occurrence.verification_status == 'verified')
    rows = db.scalars(stmt.limit(5000)).all()
    return [{'id':r.id,'fungus_id':r.fungus_id,'country_code':r.country_code,'country_name':r.country_name,'latitude':r.latitude,'longitude':r.longitude,'year':r.event_year,'recorded_by':r.recorded_by,'identified_by':r.identified_by,'source':r.source,'source_record_id':r.source_record_id,'citation':r.citation,'source_url':r.source_url,'verification_status':r.verification_status} for r in rows]

@app.get('/references')
def references(fungus_id: int | None = None, db: Session = Depends(get_db)):
    stmt = select(Reference)
    if fungus_id is not None: stmt = stmt.where(Reference.fungus_id == fungus_id)
    return [{'title':r.title,'authors':r.authors,'year':r.publication_year,'doi':r.doi,'url':r.url,'source_type':r.source_type} for r in db.scalars(stmt.limit(1000)).all()]

@app.post('/diagnose')
async def diagnose(image: UploadFile = File(...)):
    if image.content_type not in {'image/jpeg','image/png','image/webp'}: raise HTTPException(415,'Upload JPEG, PNG or WebP image')
    data = await image.read(12 * 1024 * 1024 + 1)
    if len(data) > 12 * 1024 * 1024: raise HTTPException(413,'Image exceeds 12 MB')
    model_path = os.getenv('MYCOPHYTO_MODEL_PATH','')
    if not model_path or not os.path.isfile(model_path):
        raise HTTPException(503, detail={'code':'MODEL_NOT_INSTALLED','message':'No validated model is installed. Image was not diagnosed. Add a trained model and its validation report before enabling inference.'})
    # Deliberately fail closed until a model-specific, validated inference adapter is installed.
    raise HTTPException(503, detail={'code':'INFERENCE_ADAPTER_REQUIRED','message':'Model file exists, but no compatible inference adapter is configured. No diagnosis was generated.'})
