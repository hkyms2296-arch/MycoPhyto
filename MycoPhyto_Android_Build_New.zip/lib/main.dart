
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MycoPhytoApp());

class FungusRecord {
  final String scientificName, commonEn, commonAr, descriptionEn, descriptionAr;
  final String host, symptoms, taxonomySource, firstDescriber, discoveryNote;
  final String yearDescribed, firstReport, distributionNote;
  const FungusRecord({required this.scientificName, required this.commonEn,
    required this.commonAr, required this.descriptionEn, required this.descriptionAr,
    required this.host, required this.symptoms, required this.taxonomySource,
    required this.firstDescriber, required this.discoveryNote,
    required this.yearDescribed, required this.firstReport, required this.distributionNote});
}

// Starter entries are deliberately conservative: unknown historical fields are not fabricated.
const fungi = <FungusRecord>[
  FungusRecord(
    scientificName: 'Puccinia graminis',
    commonEn: 'Wheat stem rust', commonAr: 'صدأ الساق في الحنطة',
    descriptionEn: 'A rust fungus that causes elongated reddish-brown pustules on stems and leaf sheaths.',
    descriptionAr: 'فطر صدأ يسبب بثرات بنية محمرة مستطيلة على السيقان وأغماد الأوراق.',
    host: 'Wheat and other grasses / الحنطة وأعشاب أخرى',
    symptoms: 'Reddish-brown pustules; later dark teliospores / بثرات بنية محمرة وقد تصبح داكنة لاحقاً.',
    taxonomySource: 'Index Fungorum / MycoBank (verify current accepted record)',
    firstDescriber: 'Eriksson & Henning (taxonomic attribution requires source verification)',
    discoveryNote: 'The first observation, isolation and formal description are distinct events; verify from primary literature.',
    yearDescribed: '1894 (verify against current nomenclatural record)',
    firstReport: 'Not assigned in this starter dataset',
    distributionNote: 'Worldwide reports exist; country-by-country researcher and year records must be imported from verified literature/GBIF/EPPO.'
  ),
  FungusRecord(
    scientificName: 'Fusarium oxysporum',
    commonEn: 'Fusarium wilt pathogen complex', commonAr: 'مسبب الذبول الفيوزاريومي',
    descriptionEn: 'A species complex containing host-specialized lineages; identification to species alone may not establish forma specialis.',
    descriptionAr: 'مجموعة تضم سلالات متخصصة بالعوائل؛ تحديد النوع وحده لا يكفي دائماً لتحديد السلالة الممرضة.',
    host: 'Many crop plants, depending on lineage / محاصيل عديدة حسب السلالة',
    symptoms: 'Vascular browning, yellowing and wilting / اسمرار الأوعية واصفرار وذبول.',
    taxonomySource: 'MycoBank, Index Fungorum and peer-reviewed taxonomy',
    firstDescriber: 'Not verified in this starter dataset',
    discoveryNote: 'Historical discovery/first isolation needs a primary historical source.',
    yearDescribed: 'Not verified',
    firstReport: 'Not assigned in this starter dataset',
    distributionNote: 'Distribution varies by host-specialized lineage; do not infer a country record from a species-level map.'
  ),
];

class MycoPhytoApp extends StatefulWidget {
  const MycoPhytoApp({super.key});
  @override State<MycoPhytoApp> createState() => _MycoPhytoAppState();
}
class _MycoPhytoAppState extends State<MycoPhytoApp> {
  bool arabic = true;
  int tab = 0;
  File? selectedImage;
  final picker = ImagePicker();
  final List<String> history = [];
  String get t => arabic ? 'العربية' : 'English';

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      arabic = p.getBool('arabic') ?? true;
      history.addAll(p.getStringList('history') ?? []);
    });
  }
  Future<void> _toggleLanguage() async {
    setState(() => arabic = !arabic);
    final p = await SharedPreferences.getInstance();
    await p.setBool('arabic', arabic);
  }
  Future<void> _pick(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 88);
    if (x != null) setState(() => selectedImage = File(x.path));
  }
  Future<void> _saveCase() async {
    if (selectedImage == null) return;
    final p = await SharedPreferences.getInstance();
    final item = '${DateTime.now().toIso8601String()} | ${selectedImage!.path}';
    history.insert(0, item);
    await p.setStringList('history', history);
    setState(() {});
  }

  @override Widget build(BuildContext context) {
    final labels = arabic
      ? ['الرئيسية','موسوعة الفطريات','فحص صورة','خريطة الانتشار','المراجع']
      : ['Home','Fungi encyclopedia','Image review','Distribution map','References'];
    final titles = arabic
      ? ['MycoPhyto','الموسوعة العلمية','مراجعة صورة نبات','انتشار الفطريات','المراجع العلمية']
      : ['MycoPhyto','Scientific encyclopedia','Plant image review','Fungal distribution','Scientific references'];
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MycoPhyto',
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff16733b)), useMaterial3: true),
      home: Directionality(
        textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          appBar: AppBar(
            title: Text(titles[tab], style: const TextStyle(fontWeight: FontWeight.bold)),
            actions: [TextButton(onPressed: _toggleLanguage, child: Text(arabic ? 'English' : 'العربية'))],
          ),
          body: IndexedStack(index: tab, children: [
            _home(),
            _encyclopedia(),
            _diagnosis(),
            _distribution(),
            _references(),
          ]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (v) => setState(() => tab = v),
            destinations: [
              for (int i=0;i<5;i++) NavigationDestination(
                icon: Icon([Icons.home_outlined,Icons.menu_book_outlined,Icons.camera_alt_outlined,Icons.public,Icons.science_outlined][i]),
                label: labels[i]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(16), children: [
    ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/mycophyto_logo.jpg', fit: BoxFit.cover)),
    const SizedBox(height: 16),
    Text(arabic ? 'موسوعة علمية لتعريف وفهم فطريات النباتات' : 'Scientific plant fungi identification and reference',
      style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
    const SizedBox(height: 12),
    _tile(Icons.menu_book, arabic ? 'موسوعة الفطريات' : 'Fungi encyclopedia', () => setState(()=>tab=1)),
    _tile(Icons.camera_alt, arabic ? 'اختيار صورة للمراجعة' : 'Select an image for review', () => setState(()=>tab=2)),
    _tile(Icons.public, arabic ? 'خريطة الانتشار حسب السجلات' : 'Distribution by documented records', () => setState(()=>tab=3)),
    _tile(Icons.history, arabic ? 'سجل الصور المحفوظة: ${history.length}' : 'Saved image history: ${history.length}', () => setState(()=>tab=2)),
    const SizedBox(height: 8),
    Text(arabic
      ? 'تنبيه علمي: هذه النسخة لا تحتوي على نموذج ذكاء اصطناعي مدرّب؛ اختيار الصورة وحفظها لا يعني تشخيص المرض.'
      : 'Scientific note: this build does not include a trained AI model. Selecting and saving an image is not a diagnosis.',
      style: const TextStyle(color: Colors.deepOrange), textAlign: TextAlign.center),
  ]);

  Widget _tile(IconData icon, String title, VoidCallback action) => Card(
    child: ListTile(leading: Icon(icon, color: Colors.green), title: Text(title), trailing: const Icon(Icons.chevron_right), onTap: action));

  Widget _encyclopedia() => ListView(padding: const EdgeInsets.all(12), children: [
    Text(arabic ? 'أسماء الفطريات العلمية تبقى باللاتينية في اللغتين.' : 'Scientific fungal names remain Latin in both languages.',
      style: const TextStyle(fontWeight: FontWeight.w600)),
    for (final f in fungi) Card(
      child: ExpansionTile(
        title: Text(f.scientificName, style: const TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.bold)),
        subtitle: Text(arabic ? f.commonAr : f.commonEn),
        children: [
          _detail(arabic?'الوصف العلمي':'Scientific description', arabic?f.descriptionAr:f.descriptionEn),
          _detail(arabic?'العوائل النباتية':'Host plants', f.host),
          _detail(arabic?'الأعراض':'Symptoms', f.symptoms),
          _detail(arabic?'العالم الذي وصفه':'Formal taxonomic describer', f.firstDescriber),
          _detail(arabic?'سنة الوصف':'Year described', f.yearDescribed),
          _detail(arabic?'الاكتشاف والعزل الأول':'Discovery / first isolation', f.discoveryNote),
          _detail(arabic?'أول تسجيل جغرافي':'First geographic report', f.firstReport),
          _detail(arabic?'الانتشار الحالي':'Current distribution', f.distributionNote),
          _detail(arabic?'مصدر التصنيف':'Taxonomic source', f.taxonomySource),
        ],
      ),
    ),
  ]);

  Widget _detail(String title, String value) => Padding(
    padding: const EdgeInsets.fromLTRB(16,4,16,10),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
      Text(value),
    ]));

  Widget _diagnosis() => ListView(padding: const EdgeInsets.all(16), children: [
    Text(arabic ? 'أرفق صورة واضحة للورقة أو الساق أو الجذر أو العينة المجهرية.' : 'Choose a clear image of a leaf, stem, root or microscopic specimen.'),
    const SizedBox(height: 12),
    if (selectedImage != null) ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(selectedImage!, height: 250, fit: BoxFit.contain))
    else Container(height: 180, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.green.withOpacity(.08), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.image_search, size: 72, color: Colors.green)),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: ()=>_pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: Text(arabic?'التقاط صورة':'Take photo')),
    OutlinedButton.icon(onPressed: ()=>_pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: Text(arabic?'اختيار من المعرض':'Choose from gallery')),
    FilledButton.tonal(onPressed: selectedImage==null?null:_saveCase, child: Text(arabic?'حفظ الصورة في السجل':'Save image to history')),
    const SizedBox(height: 12),
    Text(arabic
      ? 'لا يوجد تشخيص آلي مؤكد في هذه النسخة. يلزم ربط نموذج مدرّب ومختبر، مع فحوص مختبرية للتأكيد.'
      : 'Automated diagnosis is not enabled in this build. A trained and validated model plus laboratory confirmation workflow are required.',
      style: const TextStyle(color: Colors.deepOrange)),
    const SizedBox(height: 12),
    Text(arabic?'سجل الصور':'Image history', style: Theme.of(context).textTheme.titleMedium),
    for (final h in history) ListTile(leading: const Icon(Icons.history), title: Text(h, maxLines: 1, overflow: TextOverflow.ellipsis)),
  ]);

  Widget _distribution() => ListView(padding: const EdgeInsets.all(16), children: [
    Text(arabic?'خريطة التسجيلات العلمية':'Scientific occurrence records', style: Theme.of(context).textTheme.titleLarge),
    const SizedBox(height: 8),
    Text(arabic
      ? 'هذه الشاشة مهيأة لعرض سجلات الدول بعد استيراد بيانات موثقة. لا نعرض دولاً أو أسماء باحثين بلا مرجع.'
      : 'This screen is prepared for country records after verified data import. Countries and researchers are not shown without sources.'),
    const SizedBox(height: 16),
    for (final f in fungi) Card(child: ListTile(
      leading: const Icon(Icons.public, color: Colors.green),
      title: Text(f.scientificName, style: const TextStyle(fontStyle: FontStyle.italic)),
      subtitle: Text(f.distributionNote),
      onTap: ()=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text(f.scientificName),content:Text(f.distributionNote),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))])),
    )),
    const SizedBox(height: 8),
    Text(arabic?'مصادر مقترحة للاستيراد: GBIF وEPPO وبيانات الأبحاث المحكمة. يجب توثيق الباحث والسنة لكل سجل دولة.':'Import sources: GBIF, EPPO and peer-reviewed papers. Each country record must retain its researcher and year.'),
  ]);

  Widget _references() => ListView(padding: const EdgeInsets.all(16), children: [
    _ref('Index Fungorum', 'https://www.indexfungorum.org/', arabic?'الأسماء والتصنيف الفطري':'Fungal names and taxonomy'),
    _ref('MycoBank', 'https://www.mycobank.org/', arabic?'التسميات والبيانات التصنيفية':'Nomenclature and taxonomic data'),
    _ref('GBIF', 'https://www.gbif.org/', arabic?'سجلات الحدوث الجغرافي مع مراجعة جودة البيانات':'Geographic occurrence records; review data quality'),
    _ref('EPPO Global Database', 'https://gd.eppo.int/', arabic?'بيانات الآفات النباتية وتوزيعها':'Plant pest data and distribution'),
    _ref('NCBI Taxonomy', 'https://www.ncbi.nlm.nih.gov/taxonomy', arabic?'المراجع والتصنيف الحيوي':'Bio-taxonomy and linked literature'),
    const SizedBox(height: 12),
    Text(arabic?'يجب مراجعة كل مرجع وتسجيل DOI أو رابط الورقة وسنة النشر قبل اعتماد سجل جغرافي أو تاريخي.':'Verify each source and retain DOI, paper link and publication year before accepting historical or geographic records.'),
  ]);

  Widget _ref(String name, String url, String note) => Card(child: ListTile(
    leading: const Icon(Icons.link, color: Colors.green),
    title: Text(name), subtitle: Text(note), onTap: () {},
    trailing: const Icon(Icons.open_in_new),
  ));
}
